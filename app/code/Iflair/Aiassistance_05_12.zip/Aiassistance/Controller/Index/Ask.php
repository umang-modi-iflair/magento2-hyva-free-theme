<?php
namespace Vendor\AiAssistance\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Iflair\AiAssistance\Model\AiService;
use Magento\Framework\Controller\Result\JsonFactory;

class Ask extends Action
{
    protected $aiService;
    protected $resultJsonFactory;

    public function __construct(
        Context $context,
        AiService $aiService,
        JsonFactory $resultJsonFactory
    ) {
        parent::__construct($context);
        $this->aiService = $aiService;
        $this->resultJsonFactory = $resultJsonFactory;
    }

    public function execute()
    {
        $question = $this->getRequest()->getParam('question');
        $productId = $this->getRequest()->getParam('productId');

        $response = $this->aiService->ask($question, $productId);

        return $this->resultJsonFactory
            ->create()
            ->setData($response);
    }
}
