<?php
namespace Iflair\Aiassistance\Model;

use Iflair\Aiassistance\Api\AskInterface;
use Iflair\Aiassistance\Model\OllamaClient;

class Ask implements AskInterface
{
    protected $ollamaClient;

    public function __construct(
        OllamaClient $ollamaClient
    ) {
        $this->ollamaClient = $ollamaClient;
    }

    public function ask($question)
    {
        $resp = $this->ollamaClient->askModel($question);

        if (!isset($resp['success']) || !$resp['success']) {
            return [
                'success' => false,
                'message' => $resp['message'] ?? 'No response from AI model',
                'model'   => null
            ];
        }

        return [
            'success' => true,
            'message' => $resp['response'],   // <-- correct
            'model'   => $resp['model']
        ];
    }

    public function testConnection()
    {
        return $this->ollamaClient->testConnection();
    }
}
