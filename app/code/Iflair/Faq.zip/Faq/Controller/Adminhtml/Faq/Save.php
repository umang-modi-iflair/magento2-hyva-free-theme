<?php
namespace Iflair\Faq\Controller\Adminhtml\Faq;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\LocalizedException;
use Iflair\Faq\Model\FaqFactory;
use Iflair\Faq\Model\ResourceModel\Faq as FaqResource;

class Save extends Action
{
    const ADMIN_RESOURCE = 'Iflair_Faq::faq_save';

    protected $faqFactory;
    protected $faqResource;

    public function __construct(
        Action\Context $context,
        FaqFactory $faqFactory,
        FaqResource $faqResource
    ) {
        $this->faqFactory = $faqFactory;
        $this->faqResource = $faqResource;
        parent::__construct($context);
    }

    public function execute(): ResultInterface
    {
        $data = $this->getRequest()->getPostValue();
        $resultRedirect = $this->resultRedirectFactory->create();

        if (!$data) {
            $this->messageManager->addErrorMessage(__('No data to save.'));
            return $resultRedirect->setPath('*/*/');
        }

        try {
            $id = $this->getRequest()->getParam('faq_id');
            $model = $this->faqFactory->create();

            if ($id) {
                $this->faqResource->load($model, $id);
                if (!$model->getId()) {
                    throw new LocalizedException(__('This FAQ no longer exists.'));
                }
            }

            if (empty($data['question']) || trim($data['question']) === '') {
                throw new LocalizedException(__('Question is required.'));
            }
            if (empty($data['answer']) || trim($data['answer']) === '') {
                throw new LocalizedException(__('Answer is required.'));
            }

            if (isset($data['store_view']) && is_array($data['store_view'])) {
                $data['store_view'] = implode(',', array_filter($data['store_view']));
            }

            if (isset($data['customer_group']) && is_array($data['customer_group'])) {
                $data['customer_group'] = implode(',', array_filter($data['customer_group']));
            }

            $model->addData($data);
            $this->faqResource->save($model);

            $this->messageManager->addSuccessMessage(__('FAQ saved successfully.'));

            if ($this->getRequest()->getParam('back')) {
                return $resultRedirect->setPath('*/*/edit', ['faq_id' => $model->getId()]);
            }

            return $resultRedirect->setPath('*/*/index');

        } catch (LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
            return $resultRedirect->setPath('*/*/edit', ['faq_id' => $this->getRequest()->getParam('faq_id')]);
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the FAQ.'));
            return $resultRedirect->setPath('*/*/edit', ['faq_id' => $this->getRequest()->getParam('faq_id')]);
        }
    }
}