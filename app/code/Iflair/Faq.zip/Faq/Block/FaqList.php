<?php

namespace Iflair\Faq\Block;

use Magento\Framework\View\Element\Template;
use Iflair\Faq\Model\ResourceModel\Faq\CollectionFactory;

class FaqList extends Template
{
    protected $collectionFactory;

    public function __construct(
        Template\Context $context,
        CollectionFactory $collectionFactory,
        array $data = []
    ) {
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context, $data);
    }

    /**
     * Get approved FAQs for current product
     *
     * @return \Iflair\Faq\Model\ResourceModel\Faq\Collection
     */
    
    public function getFaqs()
    {
        $productBlock = $this->getLayout()->getBlock('product.info');
        if (!$productBlock) {
            return [];
        }

        $product = $productBlock->getProduct();
        if (!$product) {
            return [];
        }

        $collection = $this->collectionFactory->create();
        $collection->addFieldToFilter('product_id', $product->getId());
        $collection->addFieldToFilter('status', 2);
        $collection->setOrder('faq_id', 'DESC');

        return $collection;
    }
}
