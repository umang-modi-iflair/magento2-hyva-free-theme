<?php
namespace Iflair\Faq\Model\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Source Model for FAQ Visibility status (e.g., Public or Hidden).
 */
class VisibilityOptions implements ArrayInterface
{
    /**
     * Visibility Status: Public
     */
    const VISIBILITY_PUBLIC = 1;

    /**
     * Visibility Status: Hidden/Private
     */
    const VISIBILITY_HIDDEN = 2;

    /**
     * Return array of options as value-label pairs
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => self::VISIBILITY_PUBLIC,
                'label' => __('Public')
            ],
            [
                'value' => self::VISIBILITY_HIDDEN,
                'label' => __('Hidden')
            ]
        ];
    }
}