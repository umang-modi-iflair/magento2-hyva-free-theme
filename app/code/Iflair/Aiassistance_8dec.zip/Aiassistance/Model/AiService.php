<?php
namespace Iflair\Aiassistance\Model;

use Iflair\Aiassistance\Api\AskInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;

class AiService implements AskInterface
{
    protected $productRepository;

    public function __construct(
        ProductRepositoryInterface $productRepository
    ) {
        $this->productRepository = $productRepository;
    }

    public function ask($question, $productId = null)
    {
        $productContext = "";

        if ($productId) {
            try {
                $product = $this->productRepository->getById($productId);

                $productContext =
                    "Product Name: " . $product->getName() . "\n" .
                    "SKU: " . $product->getSku() . "\n" .
                    "Price: " . $product->getFinalPrice() . "\n" .
                    "Short Description: " . strip_tags($product->getShortDescription()) . "\n" .
                    "Full Description: " . strip_tags($product->getDescription());
            } catch (\Exception $e) {}
        }

        $prompt = "User Question: {$question}\n\nProduct Context:\n{$productContext}";

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "http://localhost:11434/api/generate",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode([
                "model" => "qwen2.5:3b",
                "prompt" => $prompt,
                "stream" => false
            ])
        ]);

        $response = curl_exec($curl);
        $error = curl_error($curl);
        curl_close($curl);

        if ($error) {
            return ['success' => false, 'message' => $error];
        }

        $data = json_decode($response, true);

        return [
            'success' => true,
            'message' => $data['response'] ?? "No response"
        ];
    }

    // 🔥 REQUIRED METHOD — missing earlier
    public function testConnection()
    {
        return [
            'success' => true,
            'message' => 'AI connection test successful.'
        ];
    }
}
