<?php
namespace Iflair\Aiassistance\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\HTTP\Client\Curl;
use Psr\Log\LoggerInterface;

class OllamaClient
{
    const CONFIG_PATH_OLLAMA_URL    = 'iflair_aiassistance/general/ollama_endpoint';
    const CONFIG_PATH_OLLAMA_MODEL  = 'iflair_aiassistance/general/model_name';
    const CONFIG_PATH_OLLAMA_TIMEOUT = 'iflair_aiassistance/general/timeout';
    const CONFIG_PATH_OLLAMA_APIKEY  = 'iflair_aiassistance/general/api_key';

    protected $scopeConfig;
    protected $curl;
    protected $logger;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        Curl $curl,
        LoggerInterface $logger
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->curl = $curl;
        $this->logger = $logger;
    }


    public function askModel($question, $productContext = '') // UPDATED SIGNATURE
    {
        $url     = rtrim($this->scopeConfig->getValue(self::CONFIG_PATH_OLLAMA_URL) ?: 'http://127.0.0.1:11434', '/');
        $model   = $this->scopeConfig->getValue(self::CONFIG_PATH_OLLAMA_MODEL) ?: 'qwen2.5:3b';
        $timeout = (int)($this->scopeConfig->getValue(self::CONFIG_PATH_OLLAMA_TIMEOUT) ?: 60);

       if ($timeout < 30) { $timeout = 60; }

        $fullPrompt = '';

        if (!empty($productContext)) {
            // SCENARIO 1: Product Context is Available (Product Page)
            $systemPrompt = "You are an expert product assistant for an e-commerce store. Answer the customer's question **ONLY by analyzing and summarizing the PRODUCT DATA provided**. If the information (e.g., if it's refillable, or what colors are available) is not explicitly stated in the data, you must truthfully state: 'I am sorry, that detail is not specified in the product data.'";

            $fullPrompt .= $systemPrompt . "\n\n";
            $fullPrompt .= "--- PRODUCT DATA START ---\n";
            $fullPrompt .= $productContext . "\n"; 
            $fullPrompt .= "--- PRODUCT DATA END ---\n\n";

        } else {
            // SCENARIO 2: No Product Context (General Page / Random Query)
            $systemPrompt = "You are a friendly and helpful general virtual assistant for an e-commerce store. Answer the customer's question knowledgeably. If the query is about a specific product you don't have details for, say so. Do not invent product details. Keep your responses concise.";
            
            $fullPrompt .= $systemPrompt . "\n\n";
        }
        
        $fullPrompt .= "CUSTOMER QUESTION: " . $question;
        
        $postData = [
            'model'  => $model,
            'prompt' => $fullPrompt,
            'stream' => false 
        ];

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL            => $url . "/api/generate",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS     => json_encode($postData),
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => true,
        ]);

        $response = curl_exec($curl);
        $error    = curl_error($curl);
        curl_close($curl);

        if ($error || !$response) {
            return [
                'success' => false,
                'message' => "Ollama error: " . ($error ?: 'No response (timeout)')
            ];
        }

        $parsed = json_decode($response, true);

        return [
            'success'  => true,
            'response' => $parsed['response'] ?? 'Empty response',
            'model'    => $model
        ];
    }


    /**
     * Test Ollama connection and installed models (remains unchanged)
     */
    public function testConnection()
    {
        try {
            $url   = rtrim($this->scopeConfig->getValue(self::CONFIG_PATH_OLLAMA_URL) ?: 'http://localhost:11434', '/');
            $apiKey = $this->scopeConfig->getValue(self::CONFIG_PATH_OLLAMA_APIKEY);

            $this->curl->setOption(CURLOPT_TIMEOUT, 10);
            $this->curl->addHeader('Content-Type', 'application/json');

            if (!empty($apiKey)) {
                $this->curl->addHeader('Authorization', 'Bearer ' . $apiKey);
            }

            $this->curl->get($url . '/api/tags');
            $status = $this->curl->getStatus();
            $body   = $this->curl->getBody();

            if ($status !== 200) {
                throw new \Exception('Ollama returned HTTP ' . $status . ' - ' . substr($body, 0, 200));
            }

            $decoded = json_decode($body, true);
            return ['success' => true, 'models' => $decoded['models'] ?? $decoded];

        } catch (\Exception $e) {
            $this->logger->error('Ollama test error: ' . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
}