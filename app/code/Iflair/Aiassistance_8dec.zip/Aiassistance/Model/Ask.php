<?php
namespace Iflair\Aiassistance\Model;

use Iflair\Aiassistance\Api\AskInterface;
use Iflair\Aiassistance\Model\OllamaClient;
use Magento\Catalog\Api\ProductRepositoryInterface; // NEW Dependency
use Magento\Catalog\Api\Data\ProductInterface; // Required for type hinting

class Ask implements AskInterface
{
    protected $ollamaClient;
    protected $productRepository;

    public function __construct(
        OllamaClient $ollamaClient,
        ProductRepositoryInterface $productRepository // Inject Product Repository
    ) {
        $this->ollamaClient = $ollamaClient;
        $this->productRepository = $productRepository;
    }

    /**
     * @inheritdoc
     */
    public function ask($question, $productId = null) // UPDATED SIGNATURE
    {
        $productContext = '';

        if ($productId) {
            try {
                // Fetch product details if ID is provided
                $product = $this->productRepository->getById($productId);
                $productContext = $this->formatProductContext($product); // Generate detailed context

            } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
                // Product ID was provided but invalid. Continue without context.
            }
        }

        // Pass question and context (which may be empty) to the Ollama client
        $resp = $this->ollamaClient->askModel($question, $productContext);

        if (!isset($resp['success']) || !$resp['success']) {
            return [
                'success' => false,
                'message' => $resp['message'] ?? 'No response from AI model',
                'model'   => null
            ];
        }

        return [
            'success' => true,
            'message' => $resp['response'],
            'model'   => $resp['model']
        ];
    }

    /**     
     * @param ProductInterface $product
     * @return string
     */
    private function formatProductContext(ProductInterface $product)
    {
        // Concatenate all relevant descriptive data fields without checking specific attributes
        $shortDescription = strip_tags($product->getShortDescription());
        $fullDescription = strip_tags($product->getDescription());
        
        $context = sprintf(
            "Product Name: %s, SKU: %s, Price: %s. Short Description: %s. Full Product Description: %s.",
            $product->getName(),
            $product->getSku(),
            $product->getFinalPrice(),
            $shortDescription,
            $fullDescription
        );
        
        // Add other simple, readily available attributes if necessary (e.g., color)
        $attributes = [];
        if ($product->getData('color')) {
            // Using raw data value if source model lookup is not implemented
            $attributes[] = "Raw Color Value: " . $product->getData('color'); 
        }
        
        if (!empty($attributes)) {
            $context .= " Other Key Details: " . implode(', ', $attributes) . ".";
        }

        return $context;
    }

    public function testConnection()
    {
        return $this->ollamaClient->testConnection();
    }
}